import classes from './post.module.css'
//JSX = JS + HTML

export const Post = ({ title, description, marked }) => {
  return (
    <div className={marked ? classes.marked : classes.postContainer}>
      <h1>{title}</h1>
      <p>{description}</p>
    </div>
  )
}
