import { posts } from '../../utils/posts'
import { Post } from '../Post/Post'

export const PostList = () => {
  console.log(posts)
  // все вычисления до return
  // return возвращает всегда один элемент HTML
  return (
    <div>
      {posts.map((post) => (
        <Post {...post} />
      ))}
    </div>
  )
}
